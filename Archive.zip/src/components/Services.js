import React from "react";

export default function Services() {
    return (
        <section>
            <h1>Services</h1>
        </section>
    );
};